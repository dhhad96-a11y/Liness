-- Z7 database schema for Supabase (PostgreSQL)
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key default gen_random_uuid(),
  username text unique not null,
  password_hash text not null,
  role text not null default 'user' check (role in ('owner','user')),
  balance numeric(12,2) not null default 0 check (balance >= 0),
  created_at timestamptz not null default now()
);
create table if not exists public.sessions (
  token_hash text primary key,
  user_id uuid not null references public.profiles(id) on delete cascade,
  expires_at timestamptz not null,
  created_at timestamptz not null default now()
);
create table if not exists public.license_keys (
  id uuid primary key default gen_random_uuid(),
  key_value text unique not null,
  status text not null default 'available' check (status in ('available','used')),
  created_by uuid references public.profiles(id) on delete set null,
  owner_id uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now()
);
create table if not exists public.transactions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete set null,
  type text not null,
  description text not null default '',
  amount numeric(12,2) not null default 0,
  created_at timestamptz not null default now()
);

-- Turn off direct public table access. Server API uses service role key only.
alter table public.profiles enable row level security;
alter table public.sessions enable row level security;
alter table public.license_keys enable row level security;
alter table public.transactions enable row level security;

-- Transactional purchase: row lock, verify balance, reserve keys, debit exact $1/key.
create or replace function public.z7_purchase_keys(p_user_id uuid, p_count integer)
returns jsonb language plpgsql security definer set search_path=public as $$
declare
  v_balance numeric(12,2);
  v_keys text[];
  v_found integer;
begin
  if p_count is null or p_count < 1 or p_count > 50 then
    raise exception 'INVALID_COUNT';
  end if;
  select balance into v_balance from profiles where id=p_user_id and role='user' for update;
  if not found then raise exception 'USER_NOT_FOUND'; end if;
  if v_balance < p_count then raise exception 'INSUFFICIENT_BALANCE'; end if;

  with picked as (
    select id from license_keys where status='available'
    order by created_at asc for update skip locked limit p_count
  ), updated as (
    update license_keys k set status='used', owner_id=p_user_id
    from picked where k.id=picked.id returning k.key_value
  )
  select array_agg(key_value), count(*) into v_keys,v_found from updated;
  if coalesce(v_found,0) < p_count then raise exception 'NOT_ENOUGH_KEYS'; end if;

  update profiles set balance=balance-p_count where id=p_user_id;
  insert into transactions(user_id,type,description,amount)
  values(p_user_id,'purchase',format('شراء %s مفتاح',p_count),-p_count);
  return jsonb_build_object('keys',v_keys,'charged',p_count);
end; $$;

-- Create owner account with a SHA-256 password hash.
-- Owner username/password: ADHAM / 8189
insert into public.profiles(username,password_hash,role,balance)
values ('ADHAM', encode(digest('8189','sha256'),'hex'), 'owner', 0)
on conflict (username) do update set role='owner', password_hash=excluded.password_hash;

-- Optional initial keys so you can test purchase immediately.
insert into public.license_keys(key_value,status,created_by)
select 'Z7-DEMO-'||upper(substr(encode(gen_random_bytes(8),'hex'),1,12)), 'available',
 (select id from public.profiles where username='ADHAM')
from generate_series(1,5);

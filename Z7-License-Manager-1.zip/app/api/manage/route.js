import { createClient } from "@supabase/supabase-js";
import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import crypto from "node:crypto";

export const runtime = "nodejs";
const supabase = () => createClient(process.env.NEXT_PUBLIC_SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY, {auth:{persistSession:false}});
const hash = value => crypto.createHash("sha256").update(value).digest("hex");
const sessionCookie = "z7_session";
async function currentUser(db) {
  const jar = await cookies();
  const token = jar.get(sessionCookie)?.value;
  if (!token) return null;
  const {data} = await db.from("sessions").select("user_id, expires_at").eq("token_hash",hash(token)).maybeSingle();
  if (!data || new Date(data.expires_at) < new Date()) return null;
  const {data:user} = await db.from("profiles").select("id,username,role,balance,created_at").eq("id",data.user_id).maybeSingle();
  return user || null;
}
const response = (data,status=200) => NextResponse.json(data,{status});
export async function POST(req) {
  try {
    if (!process.env.NEXT_PUBLIC_SUPABASE_URL || !process.env.SUPABASE_SERVICE_ROLE_KEY) return response({error:"أكمل إعداد متغيرات Supabase أولًا."},503);
    const body = await req.json(); const db = supabase();
    if (body.action === "login") {
      const username = String(body.username||"").trim();
      const password = String(body.password||"");
      if (!username || !password) return response({error:"أدخل اسم المستخدم وكلمة المرور."},400);
      const {data:user} = await db.from("profiles").select("id,password_hash").eq("username",username).maybeSingle();
      if (!user || user.password_hash !== hash(password)) return response({error:"اسم المستخدم أو كلمة المرور غير صحيحين."},401);
      const token = crypto.randomBytes(32).toString("hex");
      await db.from("sessions").delete().lt("expires_at",new Date().toISOString());
      const {error} = await db.from("sessions").insert({user_id:user.id,token_hash:hash(token),expires_at:new Date(Date.now()+7*86400000).toISOString()});
      if (error) throw error;
      const res = response({ok:true,message:"تم تسجيل الدخول."});
      res.cookies.set(sessionCookie,token,{httpOnly:true,secure:process.env.NODE_ENV==="production",sameSite:"lax",path:"/",maxAge:7*86400});
      return res;
    }
    if (body.action === "logout") {
      const jar=await cookies(); const token=jar.get(sessionCookie)?.value;
      if(token) await db.from("sessions").delete().eq("token_hash",hash(token));
      const res=response({ok:true,message:"تم تسجيل الخروج."});res.cookies.set(sessionCookie,"",{path:"/",maxAge:0});return res;
    }
    const user = await currentUser(db);
    if (!user) return response({error:"سجّل الدخول للمتابعة."},401);
    if (body.action === "overview") {
      const [us,ks,ts] = await Promise.all([
        db.from("profiles").select("id,username,role,balance,created_at").order("created_at",{ascending:false}),
        db.from("license_keys").select("id,key_value,status,owner_id,created_at,owner:profiles!license_keys_owner_id_fkey(username)").order("created_at",{ascending:false}).limit(500),
        db.from("transactions").select("id,type,description,amount,created_at").order("created_at",{ascending:false}).limit(200)
      ]);
      if(us.error||ks.error||ts.error) throw us.error||ks.error||ts.error;
      const users = user.role==="owner" ? us.data : us.data.filter(x=>x.id===user.id);
      const keys = user.role==="owner" ? ks.data : ks.data.filter(x=>x.owner_id===user.id || x.status==="available");
      return response({profile:user,users,keys:keys.map(k=>({...k,owner_username:k.owner?.username||null})),transactions: user.role==="owner"?ts.data:ts.data.filter(t=>t.user_id===user.id)});
    }
    if (user.role !== "owner" && !["buy_keys"].includes(body.action)) return response({error:"هذه العملية متاحة للمالك فقط."},403);
    if (body.action === "create_user") {
      const username=String(body.username||"").trim(), password=String(body.password||"");
      const balance=Number(body.balance||0);
      if(username.length<3||password.length<4||!Number.isFinite(balance)||balance<0) return response({error:"اسم المستخدم 3 أحرف على الأقل، وكلمة المرور 4 أحرف، والرصيد غير سالب."},400);
      const {data,error}=await db.from("profiles").insert({username,password_hash:hash(password),role:"user",balance}).select("id").single();
      if(error) return response({error:error.code==="23505"?"اسم المستخدم موجود بالفعل.":error.message},400);
      await db.from("transactions").insert({user_id:data.id,type:"create_user",description:`إنشاء الحساب ${username}`,amount:balance});
      return response({message:"تم إنشاء الحساب وحفظه."});
    }
    if (body.action === "delete_user") {
      const id=String(body.user_id||"");
      const {data:target}=await db.from("profiles").select("role").eq("id",id).maybeSingle();
      if(!target||target.role==="owner") return response({error:"لا يمكن حذف حساب المالك أو الحساب غير الموجود."},400);
      const {error}=await db.from("profiles").delete().eq("id",id);
      if(error) throw error;
      return response({message:"تم حذف الحساب."});
    }
    if (body.action === "add_balance") {
      const amount=Number(body.amount), id=String(body.user_id||"");
      if(!Number.isFinite(amount)||amount<=0||!id) return response({error:"أدخل حسابًا ومبلغًا صحيحًا."},400);
      const {data:target}=await db.from("profiles").select("id,username,balance,role").eq("id",id).maybeSingle();
      if(!target) return response({error:"الحساب غير موجود."},404);
      const {error}=await db.from("profiles").update({balance:Number(target.balance)+amount}).eq("id",id);
      if(error) throw error;
      await db.from("transactions").insert({user_id:id,type:"credit",description:`إضافة رصيد للحساب ${target.username}`,amount});
      return response({message:"تمت إضافة الرصيد."});
    }
    if (body.action === "create_keys") {
      const count=Number(body.count);
      if(!Number.isInteger(count)||count<1||count>100) return response({error:"عدد المفاتيح من 1 إلى 100."},400);
      const rows=Array.from({length:count},()=>({key_value:"Z7-"+crypto.randomBytes(12).toString("hex").toUpperCase(),status:"available",created_by:user.id}));
      const {error}=await db.from("license_keys").insert(rows);
      if(error) throw error;
      await db.from("transactions").insert({user_id:user.id,type:"create_keys",description:`إنشاء ${count} مفتاح`,amount:0});
      return response({message:`تم إنشاء ${count} مفتاح وحفظها.`});
    }
    if (body.action === "buy_keys") {
      const count=Number(body.count);
      if(!Number.isInteger(count)||count<1||count>50) return response({error:"عدد المفاتيح من 1 إلى 50."},400);
      const {data,error}=await db.rpc("z7_purchase_keys",{p_user_id:user.id,p_count:count});
      if(error) return response({error:error.message.includes("INSUFFICIENT_BALANCE")?"رصيدك غير كافٍ لإتمام الشراء.":error.message},400);
      return response({message:`تم شراء ${count} مفتاح وخصم $${(count).toFixed(2)} من رصيدك.`});
    }
    return response({error:"طلب غير معروف."},400);
  } catch(e) { return response({error:e?.message||"حدث خطأ غير متوقع."},500); }
}
import "./style.css";
export const metadata = { title: "Z7 | License Manager", description: "Z7 key and account management" };
export default function RootLayout({ children }) {
  return <html lang="ar" dir="rtl"><body>{children}</body></html>;
}
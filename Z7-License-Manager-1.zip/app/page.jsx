 "use client";
import { useEffect, useState } from "react";

const money = n => `$${Number(n || 0).toFixed(2)}`;
export default function Home() {
  const [session, setSession] = useState(null);
  const [profile, setProfile] = useState(null);
  const [view, setView] = useState("dashboard");
  const [users, setUsers] = useState([]);
  const [keys, setKeys] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [notice, setNotice] = useState("");
  const [busy, setBusy] = useState(false);
  const [login, setLogin] = useState({username:"", password:""});
  const [newUser, setNewUser] = useState({username:"",password:"",balance:"0"});
  const [credit, setCredit] = useState({user_id:"",amount:""});
  const [keyCount, setKeyCount] = useState("1");
  const [buyCount, setBuyCount] = useState("1");

  async function api(action, data={}) {
    const r = await fetch("/api/manage", {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action,...data})});
    const j = await r.json();
    if (!r.ok) throw new Error(j.error || "حدث خطأ");
    return j;
  }
  async function refresh() {
    try {
      const d = await api("overview");
      setProfile(d.profile); setUsers(d.users || []); setKeys(d.keys || []); setTransactions(d.transactions || []);
    } catch(e) { setNotice(e.message); }
  }
  useEffect(() => { refresh(); }, []);
  async function submitLogin(e) {
    e.preventDefault(); setBusy(true); setNotice("");
    try { await api("login", login); await refresh(); }
    catch(e) { setNotice(e.message); }
    finally { setBusy(false); }
  }
  async function run(action, data={}) {
    setBusy(true); setNotice("");
    try { const result = await api(action,data); setNotice(result.message || "تمت العملية بنجاح"); await refresh(); }
    catch(e) { setNotice(e.message); }
    finally { setBusy(false); }
  }
  if (!profile) return <main className="login-shell"><section className="login-card">
    <div className="logo">Z7<span>.</span></div><p className="muted">إدارة التراخيص والمفاتيح</p>
    <h1>تسجيل الدخول</h1><form onSubmit={submitLogin}>
      <label>اسم المستخدم</label><input value={login.username} onChange={e=>setLogin({...login,username:e.target.value})} autoComplete="username" required />
      <label>كلمة المرور</label><input type="password" value={login.password} onChange={e=>setLogin({...login,password:e.target.value})} autoComplete="current-password" required />
      <button disabled={busy}>{busy?"جارٍ الدخول…":"دخول إلى لوحة التحكم"}</button>
    </form>{notice && <p className="notice">{notice}</p>}
    <p className="tiny">يجب إعداد قاعدة البيانات أولًا قبل تسجيل الدخول.</p>
  </section></main>;
  const isAdmin = profile.role === "owner";
  return <div className="app-shell">
    <aside className="sidebar"><div className="logo">Z7<span>.</span></div><div className="side-caption">لوحة الإدارة</div>
      {[["dashboard","نظرة عامة","◫"],["keys","المفاتيح والأكواد","⌘"],["users","الحسابات","♙"],["transactions","المعاملات","↔"]].map(([id,label,ico])=><button key={id} className={view===id?"nav active":"nav"} onClick={()=>setView(id)}><span>{ico}</span>{label}</button>)}
      <div className="side-bottom"><div className="user-chip"><b>{profile.username}</b><small>{isAdmin?"المالك":"مستخدم"}</small></div><button className="nav" onClick={()=>run("logout")}>↪ تسجيل الخروج</button></div>
    </aside>
    <main className="main"><header><div><div className="eyebrow">Z7 / LICENSE MANAGER</div><h1>{({dashboard:"نظرة عامة",keys:"المفاتيح والأكواد",users:"إدارة الحسابات",transactions:"سجل المعاملات"})[view]}</h1></div><div className="top-user"><span className="status-dot"></span>{profile.username}<span className="avatar">{profile.username.slice(0,1).toUpperCase()}</span></div></header>
      {notice && <div className="notice banner">{notice}<button onClick={()=>setNotice("")}>×</button></div>}
      {view==="dashboard" && <><div className="welcome"><div><span className="tag">لوحة Z7</span><h2>مرحبًا بك، {profile.username}</h2><p>تابع الأرصدة والمفاتيح وحركة الحسابات من مكان واحد.</p></div><div className="welcome-mark">Z7</div></div>
        <div className="stats"><Stat label="رصيدي" value={money(profile.balance)} hint="الرصيد الحالي"/><Stat label="إجمالي المفاتيح" value={keys.length} hint="كل المفاتيح المسجلة"/><Stat label="الحسابات" value={users.length} hint="الحسابات النشطة"/><Stat label="المعاملات" value={transactions.length} hint="سجل العمليات"/></div>
        <section className="panel"><div className="panel-head"><div><h3>أحدث المعاملات</h3><p>آخر العمليات المسجلة في النظام</p></div><button className="subtle" onClick={()=>setView("transactions")}>عرض الكل ←</button></div><Transactions rows={transactions.slice(0,6)}/></section>
      </>}
      {view==="keys" && <><section className="panel"><div className="panel-head"><div><h3>المفاتيح</h3><p>إنشاء المفاتيح ومراجعة حالتها</p></div>{isAdmin&&<div className="inline"><input className="small-input" type="number" min="1" max="100" value={keyCount} onChange={e=>setKeyCount(e.target.value)}/><button onClick={()=>run("create_keys",{count:Number(keyCount)})} disabled={busy}>＋ إنشاء مفاتيح</button></div>}</div><Keys rows={keys}/></section>
        {!isAdmin&&<section className="panel"><div className="panel-head"><div><h3>شراء مفاتيح</h3><p>سعر المفتاح الواحد $1.00، ويجب توفر رصيد كافٍ.</p></div></div><div className="buy-row"><input type="number" min="1" max="50" value={buyCount} onChange={e=>setBuyCount(e.target.value)}/><span>الإجمالي: <b>{money(Number(buyCount)*1)}</b></span><button onClick={()=>run("buy_keys",{count:Number(buyCount)})} disabled={busy}>شراء الآن</button></div></section>}
      </>}
      {view==="users" && <><section className="panel"><div className="panel-head"><div><h3>الحسابات</h3><p>إدارة الحسابات والأرصدة</p></div></div>
        {isAdmin&&<form className="create-user" onSubmit={e=>{e.preventDefault();run("create_user",{...newUser,balance:Number(newUser.balance)});setNewUser({username:"",password:"",balance:"0"});}}><input placeholder="اسم المستخدم" value={newUser.username} onChange={e=>setNewUser({...newUser,username:e.target.value})} required/><input placeholder="كلمة المرور" type="password" value={newUser.password} onChange={e=>setNewUser({...newUser,password:e.target.value})} required/><input type="number" min="0" step=".01" placeholder="الرصيد الابتدائي" value={newUser.balance} onChange={e=>setNewUser({...newUser,balance:e.target.value})}/><button disabled={busy}>＋ إنشاء حساب</button></form>}
        {isAdmin&&<form className="create-user credit-form" onSubmit={e=>{e.preventDefault();run("add_balance",{user_id:credit.user_id,amount:Number(credit.amount)});setCredit({user_id:"",amount:""});}}><select value={credit.user_id} onChange={e=>setCredit({...credit,user_id:e.target.value})} required><option value="">اختر حسابًا لإضافة رصيد</option>{users.map(u=><option key={u.id} value={u.id}>{u.username}</option>)}</select><input type="number" min=".01" step=".01" placeholder="المبلغ بالدولار" value={credit.amount} onChange={e=>setCredit({...credit,amount:e.target.value})} required/><button disabled={busy}>إضافة الرصيد</button></form>}
        <Users rows={users} admin={isAdmin} onDelete={id=>{if(confirm("هل تريد حذف هذا الحساب؟"))run("delete_user",{user_id:id});}}/>
      </section></>}
      {view==="transactions" && <section className="panel"><div className="panel-head"><div><h3>سجل المعاملات</h3><p>سجل محفوظ لعمليات الشراء وإضافة الرصيد</p></div></div><Transactions rows={transactions}/></section>}
      <footer>Z7 License Manager <span>•</span> لوحة إدارة التراخيص</footer>
    </main>
  </div>;
}
function Stat({label,value,hint}) { return <div className="stat"><div className="stat-top"><span>{label}</span><span className="stat-icon">↗</span></div><strong>{value}</strong><small>{hint}</small></div>; }
function Table({heads,children}) {return <div className="table-wrap"><table><thead><tr>{heads.map(h=><th key={h}>{h}</th>)}</tr></thead><tbody>{children}</tbody></table></div>}
function Users({rows,admin,onDelete}) {return <Table heads={["الحساب","الدور","الرصيد","تاريخ الإنشاء",...(admin?["إجراء"]:[])]}>{rows.map(u=><tr key={u.id}><td><b>{u.username}</b></td><td><span className="pill">{u.role==="owner"?"مالك":"مستخدم"}</span></td><td className="amount">{money(u.balance)}</td><td>{new Date(u.created_at).toLocaleDateString("ar-EG")}</td>{admin&&<td><button className="danger" onClick={()=>onDelete(u.id)} disabled={u.role==="owner"}>حذف</button></td>}</tr>)}</Table>}
function Keys({rows}) {return <Table heads={["المفتاح","الحالة","المالك","تاريخ الإنشاء"]}>{rows.map(k=><tr key={k.id}><td><code>{k.key_value}</code></td><td><span className={"pill "+(k.status==="used"?"used":"")}>{k.status==="used"?"مستخدم":"متاح"}</span></td><td>{k.owner_username||"—"}</td><td>{new Date(k.created_at).toLocaleDateString("ar-EG")}</td></tr>)}</Table>}
function Transactions({rows}) {return <Table heads={["العملية","التفاصيل","المبلغ","التاريخ"]}>{rows.map(t=><tr key={t.id}><td>{({purchase:"شراء مفتاح",credit:"إضافة رصيد",create_user:"إنشاء حساب",create_keys:"إنشاء مفاتيح"})[t.type]||t.type}</td><td>{t.description||"—"}</td><td className={Number(t.amount)<0?"negative":"amount"}>{money(t.amount)}</td><td>{new Date(t.created_at).toLocaleString("ar-EG")}</td></tr>)}</Table>}
